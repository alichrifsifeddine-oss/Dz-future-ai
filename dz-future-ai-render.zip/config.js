window.DZ_API_BASE="";// اتركه فارغاً عند تشغيل الموقع من الخادم نفسه. في نسخة APK ضع رابط خادمك مثل: https://your-server.com
