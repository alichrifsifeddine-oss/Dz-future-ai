// DZ future ai — خادم صغير بلا مكتبات خارجية (Node 18+)
const http = require("http"), fs = require("fs"), path = require("path"), crypto = require("crypto");

// قراءة ملف .env يدوياً
try {
  for (const l of fs.readFileSync(path.join(__dirname, ".env"), "utf8").split(/\r?\n/)) {
    const m = l.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (m && !(m[1] in process.env)) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
  }
} catch (e) {}

const E = process.env;
const C = {
  port: +E.PORT || 3000,
  key: E.API_KEY || "",
  base: (E.BASE_URL || "https://api.openai.com/v1").replace(/\/$/, ""),
  model: E.MODEL || "",
  quick: E.MODEL_QUICK || "",
  complex: E.MODEL_COMPLEX || "",
  origin: E.ALLOWED_ORIGIN || "*",
  rpm: +E.RATE_PER_MIN || 20,
  gid: E.GOOGLE_CLIENT_ID || "",
  secret: E.SESSION_SECRET || "",
  emails: (E.ALLOWED_EMAILS || "").split(",").map(x => x.trim().toLowerCase()).filter(Boolean),
  certs: E.GOOGLE_CERTS_URL || "https://www.googleapis.com/oauth2/v3/certs",
};
if (!C.model) { console.error("خطأ: ضع اسم النموذج في MODEL داخل ملف .env"); process.exit(1); }

// ===== تسجيل الدخول بحساب Google (يُفعَّل عند ضبط GOOGLE_CLIENT_ID) =====
if (C.gid && !C.secret) { C.secret = crypto.randomBytes(32).toString("hex"); console.warn("تنبيه: SESSION_SECRET غير مضبوط، ستنتهي الجلسات عند إعادة تشغيل الخادم."); }
const b64u = b => Buffer.from(b).toString("base64url");
const sign = p => { const d = b64u(JSON.stringify(p)); return d + "." + crypto.createHmac("sha256", C.secret).update(d).digest("base64url"); };
function verifySession(t) {
  try {
    const [d, s] = String(t || "").split(".");
    const ok = crypto.createHmac("sha256", C.secret).update(d).digest("base64url");
    if (!s || s.length !== ok.length || !crypto.timingSafeEqual(Buffer.from(s), Buffer.from(ok))) return null;
    const p = JSON.parse(Buffer.from(d, "base64url").toString("utf8"));
    return p.exp > Date.now() / 1000 ? p : null;
  } catch (e) { return null; }
}
let jwks = { t: 0, keys: [] };
async function googleKey(kid) {
  if (Date.now() - jwks.t > 3600e3 || !jwks.keys.some(k => k.kid === kid)) {
    const j = await (await fetch(C.certs)).json();
    jwks = { t: Date.now(), keys: j.keys || [] };
  }
  return jwks.keys.find(k => k.kid === kid);
}
async function verifyGoogle(cred) {
  const [h, p, s] = String(cred || "").split(".");
  if (!h || !p || !s) throw new Error("format");
  const head = JSON.parse(Buffer.from(h, "base64url").toString()), pay = JSON.parse(Buffer.from(p, "base64url").toString());
  if (head.alg !== "RS256") throw new Error("alg");
  const jwk = await googleKey(head.kid);
  if (!jwk) throw new Error("kid");
  const key = crypto.createPublicKey({ key: jwk, format: "jwk" });
  if (!crypto.verify("RSA-SHA256", Buffer.from(h + "." + p), key, Buffer.from(s, "base64url"))) throw new Error("sig");
  if (!["accounts.google.com", "https://accounts.google.com"].includes(pay.iss) || pay.aud !== C.gid || !(pay.exp > Date.now() / 1000) || !pay.email_verified || !pay.sub) throw new Error("claims");
  return pay;
}

const hits = new Map();
function limited(ip) {
  const now = Date.now(), a = (hits.get(ip) || []).filter(t => now - t < 60000);
  a.push(now); hits.set(ip, a);
  return a.length > C.rpm;
}
setInterval(() => { const n = Date.now(); for (const [k, v] of hits) if (!v.some(t => n - t < 60000)) hits.delete(k); }, 60000).unref();

const MIME = { ".html": "text/html; charset=utf-8", ".js": "text/javascript", ".css": "text/css", ".svg": "image/svg+xml", ".png": "image/png", ".json": "application/json", ".ico": "image/x-icon", ".webmanifest": "application/manifest+json" };
const send = (res, code, obj) => { res.writeHead(code, { "Content-Type": "application/json; charset=utf-8" }); res.end(JSON.stringify(obj)); };

function readBody(req, max = 12e6) {
  return new Promise((ok, no) => {
    let n = 0; const b = [];
    req.on("data", c => { n += c.length; if (n > max) { no(new Error("big")); req.destroy(); } else b.push(c); });
    req.on("end", () => ok(Buffer.concat(b).toString("utf8")));
    req.on("error", no);
  });
}

async function chat(req, res) {
  let body;
  try { body = JSON.parse(await readBody(req)); } catch (e) { return send(res, 400, { code: "invalid_request" }); }
  const msgs = Array.isArray(body.messages) ? body.messages.filter(m => m && (m.role === "user" || m.role === "assistant") && typeof m.content === "string" && m.content) : [];
  if (!msgs.length || msgs[msgs.length - 1].role !== "user") return send(res, 400, { code: "invalid_request" });
  const images = (Array.isArray(body.images) ? body.images : []).filter(u => typeof u === "string" && /^data:image\/(jpeg|png|webp|gif);base64,/.test(u)).slice(0, 4);
  const out = msgs.slice(-30).map(m => ({ role: m.role, content: m.content }));
  if (images.length) {
    const last = out[out.length - 1];
    last.content = [{ type: "text", text: last.content }, ...images.map(u => ({ type: "image_url", image_url: { url: u } }))];
  }
  const model = (body.tier === "quick" && C.quick) || (body.tier === "complex" && C.complex) || C.model;
  const ac = new AbortController();
  res.on("close", () => ac.abort());
  let up;
  try {
    up = await fetch(C.base + "/chat/completions", {
      method: "POST", signal: ac.signal,
      headers: { "Content-Type": "application/json", Authorization: "Bearer " + C.key },
      body: JSON.stringify({ model, messages: out, stream: true }),
    });
  } catch (e) { return send(res, 502, { code: "upstream_unreachable" }); }
  if (!up.ok) {
    const code = up.status === 429 ? "rate_limited" : up.status === 401 || up.status === 403 ? "server_misconfigured" : images.length && up.status === 400 ? "image_rejected" : "upstream_error";
    console.error("upstream", up.status, (await up.text().catch(() => "")).slice(0, 300));
    return send(res, up.status === 429 ? 429 : 502, { code });
  }
  res.writeHead(200, { "Content-Type": "text/plain; charset=utf-8", "Cache-Control": "no-store", "X-Accel-Buffering": "no" });
  let buf = "";
  const dec = new TextDecoder();
  try {
    for await (const chunk of up.body) {
      buf += dec.decode(chunk, { stream: true });
      let i;
      while ((i = buf.indexOf("\n")) >= 0) {
        const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
        if (!line.startsWith("data:")) continue;
        const d = line.slice(5).trim();
        if (d === "[DONE]") continue;
        try { const t = JSON.parse(d).choices?.[0]?.delta?.content; if (t) res.write(t); } catch (e) {}
      }
    }
  } catch (e) {}
  res.end();
}

const PUB = __dirname;
http.createServer(async (req, res) => {
  res.setHeader("Access-Control-Allow-Origin", C.origin);
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
  res.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS");
  if (req.method === "OPTIONS") { res.writeHead(204); return res.end(); }
  const url = new URL(req.url, "http://x");
  if (url.pathname === "/api/config" && req.method === "GET") return send(res, 200, { googleClientId: C.gid });
  if (url.pathname === "/api/auth/google" && req.method === "POST") {
    if (!C.gid) return send(res, 404, { code: "not_configured" });
    try {
      const b = JSON.parse(await readBody(req, 20000));
      const g = await verifyGoogle(b.credential);
      if (C.emails.length && !C.emails.includes(String(g.email).toLowerCase())) return send(res, 403, { code: "not_allowed" });
      const prof = { sub: g.sub, email: g.email, name: g.name || g.email, picture: g.picture || "" };
      return send(res, 200, { token: sign({ ...prof, exp: Math.floor(Date.now() / 1000) + 7 * 86400 }), profile: prof });
    } catch (e) { return send(res, 401, { code: "unauthorized" }); }
  }
  if (url.pathname === "/api/chat" && req.method === "POST") {
    const ip = (req.headers["x-forwarded-for"] || req.socket.remoteAddress || "").toString().split(",")[0].trim();
    let who = ip;
    if (C.gid) {
      const u = verifySession((req.headers.authorization || "").replace(/^Bearer /, ""));
      if (!u) return send(res, 401, { code: "unauthorized" });
      who = u.sub;
    }
    if (limited(who)) return send(res, 429, { code: "rate_limited" });
    return chat(req, res).catch(() => { try { send(res, 500, { code: "error" }); } catch (e) {} });
  }
  let p = path.normalize(decodeURIComponent(url.pathname)).replace(/^(\.\.[\/\\])+/, "");
  if (p === "/" || p === "\\") p = "/index.html";
  if (p === "/.well-known/assetlinks.json") p = "/assetlinks.json";
  const f = path.join(PUB, p);
  if (!["/index.html", "/config.js", "/logo.svg", "/manifest.webmanifest", "/sw.js", "/icon-192.png", "/icon-512.png", "/icon-maskable-512.png", "/privacy.html", "/assetlinks.json"].includes(p.replace(/\\/g, "/"))) { res.writeHead(404); return res.end("Not found"); }
  fs.readFile(f, (e, d) => {
    if (e) { res.writeHead(404); return res.end("Not found"); }
    res.writeHead(200, { "Content-Type": MIME[path.extname(f)] || "application/octet-stream" });
    res.end(d);
  });
}).listen(C.port, () => console.log("DZ future ai يعمل على http://localhost:" + C.port + " — النموذج: " + C.model));
